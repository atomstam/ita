<?php

// ค่าคงที่
return [
    'webTitle_full'    => 'ระบบการเผยแพร่ข้อมูลเพื่อความโปร่งใสภาครัฐ',
    'webTitle_short'      => 'ITA',
    'webVersion' => '1.0',
    'webAuth_School' => 'โรงเรียนชื่นชมพิทยาคาร',
    'webAuth_Area' => 'สพม.มหาสารคาม',
    'webAuth_Obec' => 'สำนักงานคณะกรรมการการศึกษาขั้นพื้นฐาน',
    'webAuth_Moe' => 'กระทรวงศึกษาธิการ',
    'webHome' => 'https://ita.ccpk.ac.th',
    'area_code' => '1000101702',
    'sch_code' => '1044410634',
    'email' => 'atomy@ccpk.ac.th',
    'phone' => '089-046-9997',
    'auth' => 'ดร.ชัดสกร พิกุลทอง',
];
