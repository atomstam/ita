
	
	<script src="<?= base_url(); ?>/formlogin/js/jquery-3.3.1.min.js"></script>
    <script src="<?= base_url(); ?>/formlogin/js/popper.min.js"></script>
    <script src="<?= base_url(); ?>/formlogin/js/bootstrap.min.js"></script>
    <script src="<?= base_url(); ?>/formlogin/js/main.js"></script>
  </body>
</html>